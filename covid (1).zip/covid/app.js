var express     =require('express'),
      app       =express(),
    bodyParser  =require("body-parser"),
     mongoose   =require("mongoose"),
	passport    =require("passport"),
	LocalStrategy=require("passport-local"),
	methodOverride=require("method-override"),
	Resource=require("./models/resource"),
	Comment=require("./models/comment"),
	User=require("./models/user")
	//seedDB=require("./seeds")

//requiring routes
var commentRoutes=require("./routes/comments"),
	resourceRoutes=require("./routes/resources"),
	indexRoutes=require("./routes/index")
	
	
mongoose.connect('mongodb://localhost:27017/covid', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('Connected to DB!'))
.catch(error => console.log(error.message));
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine","ejs");
app.use(express.static(__dirname +"/public"));
app.use(methodOverride("_method"));
//
//seedDB();  //seed the database

//PASSPORT CONFIGURATION
app.use(require("express-session")({
	secret:"i hate harry potter!!",
	resave:false,
	saveUninitialized:false
}));

app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());
  

//to include login and signup in nav bar for every page when the user is not signed in and to include logout if the user is signed in
app.use(function(req,res,next){
	res.locals.currentUser=req.user;
	next();
});

app.use("/",indexRoutes);
app.use("/resources",resourceRoutes);  //appends all the campgrounfd routes with /campground
app.use("/resources/:id/comments",commentRoutes);

app.get("/aboutUs",function(req,res){
	res.render("aboutUs");
})
app.get("/contactUs",function(req,res){
	res.render("contactUs");
})

app.listen(3000, function() { 
  console.log('Covid App server has started'); 
});