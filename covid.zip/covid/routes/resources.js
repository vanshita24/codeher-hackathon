var express= require("express");
var router=express.Router();
var Resource=require("../models/resource");

//INDEX ROUTE-- to display all the campgrounds
router.get("/",function(req,res){
	//get all restaurants from DB
	Resource.find({},function(err, allresources){
		if(err){
			console.log(err);
		}
		else{
			res.render("resources/index",{resources:allresources,currentUser:req.user});
		}
	})
	
	
});
//app.get is used to display the restaurants and app.post is used to add a new restaurant

// CREATE ROUTE- add new restaurant to DB
router.post("/",isLoggedIn,function(req,res){
	//get data from form and add to the restaurants page
	var name=req.body.name;
	var image=req.body.image;
	var quantity=req.body.quantity;
	var address=req.body.address;
	var desc=req.body.description;
	var author={
		id:req.user._id,
		username:req.user.username
	};
	var newResource={name:name,image:image,quantity:quantity,address:address,description:desc,author:author}
	//create a new restaurant and save to db
	Resource.create(newResource,function(err,newlyCreated){
		if(err){
			console.log(err);
		}
		else{
			//redirect back to restaurants page
			res.redirect("/resources");
		}
	});
});
//NEW:show form to create a new restaurant
router.get("/new",isLoggedIn,function(req,res){
	res.render("resources/new.ejs");
});

//SHOW -- shows more info about one restaurant
router.get("/:id",function(req,res){
	//find the restaurant with provided id
	Resource.findById(req.params.id).populate("comments").exec(function(err,foundResource){
		if(err){
			console.log(err);
		}
		else{
			//render show template with that restaurant
	res.render("resources/show",{resource: foundResource});
		}
	});
	
});


//edit restaurant route
router.get("/:id/edit",checkResourceOwnership,function(req,res){
	Resource.findById(req.params.id,function(err,foundResource){
		res.render("resources/edit",{resource:foundResource});
	});
});
//update restaurant route
router.put("/:id",checkResourceOwnership,function(req,res){
	//find and update the correct campground
	Resource.findByIdAndUpdate(req.params.id,req.body.resource,function(err,updatedResource){
		if(err){
			res.redirect("/resources");
			console.log(err);
		}else{
			//redirect to show page
			res.redirect("/resources/"+req.params.id);
		}
	});
	
});
//DESTROY RESTAURANT ROUTE
router.delete("/:id",checkResourceOwnership,function(req,res){
	Resource.findByIdAndRemove(req.params.id,function(err){
		if(err){
			res.redirect("/resources");
		}else{
			res.redirect("/resources");
		}
	});
});

function isLoggedIn(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	res.redirect("/login")
}

function checkResourceOwnership(req,res,next){
	if(req.isAuthenticated()){
		Resource.findById(req.params.id,function(err,foundResource){
			if(err){
				res.redirect("back");
			} else{
				//does the user own the campground?
				//console.log(foundCampground.author.id);//mongoose object
				//console.log(req.user._id);//string
				if(foundResource.author.id.equals(req.user._id)){
					next();
					
				}else{
					res.redirect("back");
				}
				
		}
	});
	}
	else{
		res.redirect("back");
	}
}	




module.exports=router;
